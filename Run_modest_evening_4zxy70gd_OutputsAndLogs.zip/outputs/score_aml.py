# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
import json
import logging
import os
import pickle
import numpy as np
import pandas as pd
import joblib

import azureml.automl.core
from azureml.automl.core.shared import logging_utilities, log_server
from azureml.telemetry import INSTRUMENTATION_KEY

from inference_schema.schema_decorators import input_schema, output_schema
from inference_schema.parameter_types.numpy_parameter_type import NumpyParameterType
from inference_schema.parameter_types.pandas_parameter_type import PandasParameterType
from inference_schema.parameter_types.standard_py_parameter_type import StandardPythonParameterType

input_sample = pd.DataFrame({"# POCs": pd.Series([0], dtype="int64"), "Rent": pd.Series([0.0], dtype="float64"), "Perc Rent": pd.Series([0.0], dtype="float64"), "Average Receivables": pd.Series([0.0], dtype="float64"), "Average Overdue": pd.Series([0.0], dtype="float64"), "Overdue": pd.Series([0.0], dtype="float64"), "1 - 29 Days": pd.Series([0.0], dtype="float64"), "30 - 59 Days": pd.Series([0.0], dtype="float64"), "60 - 89 Days": pd.Series([0.0], dtype="float64"), "Payment Term Days": pd.Series([0], dtype="int64"), "Credit Limit": pd.Series([0.0], dtype="float64"), "Std Dev AR": pd.Series([0.0], dtype="float64"), "Max Credit Utilization": pd.Series([0.0], dtype="float64"), "Avg Credit Utilization": pd.Series([0.0], dtype="float64"), "Score Interval": pd.Series([0.0], dtype="float64"), "Volume Variance": pd.Series([0.0], dtype="float64"), "fb_likes": pd.Series([0.0], dtype="float64"), "fb_rating": pd.Series([0.0], dtype="float64"), "ta_reviews_average": pd.Series([0.0], dtype="float64"), "w_avg_rating": pd.Series([0.0], dtype="float64"), "FLAG_RENT_0": pd.Series([0.0], dtype="float64"), "FLAG_RENT_1": pd.Series([0], dtype="int64"), "sub_segment_Beer Bar": pd.Series([0], dtype="int64"), "sub_segment_Beer bar": pd.Series([0], dtype="int64"), "sub_segment_Bistro": pd.Series([0], dtype="int64"), "sub_segment_Local Bar": pd.Series([0], dtype="int64"), "sub_segment_Lounge Bar": pd.Series([0], dtype="int64"), "sub_segment_Not applicable": pd.Series([0], dtype="int64"), "sub_segment_Party Club": pd.Series([0], dtype="int64"), "sub_segment_Party Pub": pd.Series([0], dtype="int64"), "sub_segment_Quick Dining": pd.Series([0], dtype="int64"), "sub_segment_Recreational": pd.Series([0], dtype="int64"), "sub_segment_Restaurant": pd.Series([0], dtype="int64"), "sub_segment_Sports Bar": pd.Series([0], dtype="int64"), "sub_segment_Sports Club": pd.Series([0], dtype="int64"), "poc_image_Mainstream": pd.Series([0], dtype="int64"), "poc_image_Premium": pd.Series([0], dtype="int64"), "Payment Term_000A": pd.Series([0], dtype="int64"), "Payment Term_006I": pd.Series([0], dtype="int64"), "Payment Term_007I": pd.Series([0], dtype="int64"), "Payment Term_008I": pd.Series([0], dtype="int64"), "Payment Term_009I": pd.Series([0], dtype="int64"), "Payment Term_010I": pd.Series([0], dtype="int64"), "Payment Term_013I": pd.Series([0], dtype="int64"), "Payment Term_014E": pd.Series([0], dtype="int64"), "Payment Term_014I": pd.Series([0], dtype="int64"), "Payment Term_017I": pd.Series([0], dtype="int64"), "Payment Term_018I": pd.Series([0], dtype="int64"), "Payment Term_019I": pd.Series([0], dtype="int64"), "Payment Term_020I": pd.Series([0], dtype="int64"), "Payment Term_021I": pd.Series([0], dtype="int64"), "Payment Term_024I": pd.Series([0], dtype="int64"), "Payment Term_025I": pd.Series([0], dtype="int64"), "Payment Term_026I": pd.Series([0], dtype="int64"), "Payment Term_027I": pd.Series([0], dtype="int64"), "Payment Term_028I": pd.Series([0], dtype="int64"), "Payment Term_030I": pd.Series([0], dtype="int64"), "Payment Term_031I": pd.Series([0], dtype="int64"), "Payment Term_032I": pd.Series([0], dtype="int64"), "Payment Term_033I": pd.Series([0], dtype="int64"), "Payment Term_035I": pd.Series([0], dtype="int64"), "Payment Term_042I": pd.Series([0], dtype="int64"), "Payment Term_045I": pd.Series([0], dtype="int64"), "Payment Term_049I": pd.Series([0], dtype="int64"), "Payment Term_056I": pd.Series([0], dtype="int64"), "Payment Term_060I": pd.Series([0], dtype="int64"), "Payment Term_063I": pd.Series([0], dtype="int64"), "Payment Behavior Status_AVERAGE": pd.Series([0], dtype="int64"), "Payment Behavior Status_EXCELLENT": pd.Series([0], dtype="int64"), "Payment Behavior Status_GOOD": pd.Series([0], dtype="int64"), "Payment Behavior Status_STRUCTURAL OFFENDER": pd.Series([0], dtype="int64")})
output_sample = np.array([0])
method_sample = StandardPythonParameterType("predict")

try:
    log_server.enable_telemetry(INSTRUMENTATION_KEY)
    log_server.set_verbosity('INFO')
    logger = logging.getLogger('azureml.automl.core.scoring_script')
except:
    pass


def init():
    global model
    # This name is model.id of model that we want to deploy deserialize the model file back
    # into a sklearn model
    model_path = os.path.join(os.getenv('AZUREML_MODEL_DIR'), 'model.pkl')
    path = os.path.normpath(model_path)
    path_split = path.split(os.sep)
    log_server.update_custom_dimensions({'model_name': path_split[-3], 'model_version': path_split[-2]})
    try:
        logger.info("Loading model from path.")
        model = joblib.load(model_path)
        logger.info("Loading successful.")
    except Exception as e:
        logging_utilities.log_traceback(e, logger)
        raise

@input_schema('method', method_sample, convert_to_provided_type=False)
@input_schema('data', PandasParameterType(input_sample))
@output_schema(NumpyParameterType(output_sample))
def run(data, method="predict"):
    try:
        if method == "predict_proba":
            result = model.predict_proba(data)
        elif method == "predict":
            result = model.predict(data)
        else:
            raise Exception(f"Invalid predict method argument received ({method})")
        if isinstance(result, pd.DataFrame):
            result = result.values
        return json.dumps({"result": result.tolist()})
    except Exception as e:
        result = str(e)
        return json.dumps({"error": result})
